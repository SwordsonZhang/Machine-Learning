clear; clc
X = [1 1.5 2.5 4 6.5];
Y = [1 3 5 6 6.2];

subplot(1, 3, 1)
plot(X, Y, 'bo', 'linewidth', 2)
grid on
hold on
syms x
y = x + 1;
h1 = ezplot(y);
set(h1, 'color', 'r', 'linewidth', 2);
xlabel({'x', '(a)'}, 'fontsize', 12); ylabel('y', 'fontsize', 12);
set(gca, 'fontsize', 12);
title('Underfitting, high bias');
axis([0 8 0 8])

subplot(1, 3, 2)
plot(X, Y, 'bo', 'linewidth', 2)
grid on
hold on
syms x
y = 12.5 * (1 / (1 + exp(-1.5*x + 1.5)) - 0.5);
h1 = ezplot(y, [0 8]);
set(h1, 'color', 'r', 'linewidth', 2)
xlabel({'x', '(b)'}, 'fontsize', 12); ylabel('y', 'fontsize', 12);
set(gca, 'fontsize', 12)
title('Just right');
axis([0 8 0 8])

subplot(1, 3, 3)
plot(X, Y, 'bo', 'linewidth', 2)
grid on
hold on
syms x
y = 1 * (x - 1.5) * (x - 2.5) * (x - 4) * (x - 6.5) / ((1 - 1.5) * (1 - 2.5) * (1 - 4) * (1 - 6.5)) + ...
    3 * (x - 1) * (x - 2.5) * (x - 4) * (x - 6.5) / ((1.5 - 1) * (1.5 - 2.5) * (1.5 - 4) * (1.5 - 6.5)) + ...
    5 * (x - 1) * (x - 1.5) * (x - 4) * (x - 6.5) / ((2.5 - 1) * (2.5 - 1.5) * (2.5 - 4) * (2.5 - 6.5)) + ...
    6 * (x - 1) * (x - 1.5) * (x - 2.5) * (x - 6.5) / ((4 - 1) * (4 - 1.5) * (4 - 2.5) * (4 - 6.5)) + ...
    6.2 * (x - 1) * (x - 1.5) * (x - 2.5) * (x - 4) / ((6.5 - 1) * (6.5 - 1.5) * (6.5 - 2.5) * (6.5 - 4));
h1 = ezplot(y, [0 8]);
set(h1, 'color', 'r', 'linewidth', 2);
xlabel({'x', '(c)'}, 'fontsize', 12); ylabel('y', 'fontsize', 12);
set(gca, 'fontsize', 12);
title('Overfitting, high variance');
axis([0 8 0 8])













