x1 = [1 2 2 1.5 3 3 2.5];
y1 = [3 2 3 4 2 3 2.5];
x2 = [4 4 5 5 4.5 6 5.5 5.5];
y2 = [5 6 4 5 6 4.5 5 6];

figure(1);
plot(x1, y1, 'bo', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x2, y2, 'rx', 'Markersize', 10, 'linewidth', 2);
hold off;
axis([0 7 0 7]);
xlabel('x_1'); ylabel('x_2');
legend('positive: y = 1', 'negative: y = 0', 'fontsize', 8, 'location', 'northwest');
title('Supervised learning: classification')


figure(2);
plot(x1, y1, 'bo', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x2, y2, 'bo', 'Markersize', 10, 'linewidth', 2);
hold off;
axis([0 7 0 7]);
xlabel('x_1'); ylabel('x_2');
title('Unsupervised learning:clustering')
