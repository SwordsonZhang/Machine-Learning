clear;clc;

X = [0.5; 0.8; 1.0; 1.3; 1.5; 1.8; 2.0];
y = [2.1; 2.5; 3.2; 3.5; 3.8; 4.0; 5.0];

figure(1);
plot(X, y, 'bo', 'Markersize', 10, 'Linewidth', 2);
axis([0 3 0 6]);
xlabel('x'); ylabel('y');
grid on;

fprintf('Running gradient descent ...\n');

% Choose some alpha value
alpha = 0.1;
num_iters = 1000;
X = [ones(size(X, 1), 1) X];

% Init Theta and Run Gradient Descent 
theta = zeros(size(X, 2), 1);
[theta_history, J_history] = gradientDescentMulti(X, y, theta, alpha, num_iters);

alpha = 0.01;
[theta_history2, J_history2] = gradientDescentMulti(X, y, theta, alpha, num_iters);

alpha = 0.73;
[theta_history3, J_history3] = gradientDescentMulti(X, y, theta, alpha, num_iters);

figure(2);
plot(1:num_iters, J_history, 'r-', 'linewidth', 2);
xlabel('iterations'); ylabel('J(\theta)');

figure(3)
legend('training data', 'hypothesis function');
subplot(1, 3, 3);
X = [0.5; 0.8; 1.0; 1.3; 1.5; 1.8; 2.0];
y = [2.1; 2.5; 3.2; 3.5; 3.8; 4.0; 5.0];
plot(X, y, 'bo', 'Markersize', 10, 'Linewidth', 3);
axis([0 3 0 6]);
xlabel('x'); ylabel('y');
grid on;
hold on;
X1 = [ones(size(X, 1), 1) X];
plot(X, X1 * theta_history(end, :)', 'r-', 'Linewidth', 3);
title('J = 0.0203, \theta = [1.2351; 1.7371]');

subplot(1, 3, 1);
X = [0.5; 0.8; 1.0; 1.3; 1.5; 1.8; 2.0];
y = [2.1; 2.5; 3.2; 3.5; 3.8; 4.0; 5.0];
plot(X, y, 'bo', 'Markersize', 10, 'Linewidth', 3);
axis([0 3 0 6]);
xlabel('x'); ylabel('y');
grid on;
hold on;
X1 = [ones(size(X, 1), 1) X];
plot(X, X1 * theta_history(2, :)', 'r-', 'Linewidth', 3);
title('J = 3.3112, \theta = [0.3443; 0.4814]');

subplot(1, 3, 2);
X = [0.5; 0.8; 1.0; 1.3; 1.5; 1.8; 2.0];
y = [2.1; 2.5; 3.2; 3.5; 3.8; 4.0; 5.0];
plot(X, y, 'bo', 'Markersize', 10, 'Linewidth', 3);
axis([0 3 0 6]);
xlabel('x'); ylabel('y');
grid on;
hold on;
X1 = [ones(size(X, 1), 1) X];
plot(X, X1 * theta_history(6, :)', 'r-', 'Linewidth', 3);
title('J = 0.2642, \theta = [0.9958; 1.3930]');

figure(4);
plot(1:num_iters, J_history, 'r-', 'linewidth', 2);
hold on
plot(1:num_iters, J_history2, 'b-', 'linewidth', 2);
hold on;
plot(1:num_iters, J_history3, 'k-', 'linewidth', 2);
legend('\alpha = 0.10', '\alpha = 0.01', '\alpha = 0.73');
xlabel('iterations'); ylabel('J(\theta)');
hold off

X = [0.5; 0.8; 1.0; 1.3; 1.5; 1.8; 2.0];
y = [2.1; 2.5; 3.2; 3.5; 3.8; 4.0; 5.0];
X1 = [ones(size(X, 1), 1) X];
theta_norm = pinv(X1' * X1) * X1' * y;


