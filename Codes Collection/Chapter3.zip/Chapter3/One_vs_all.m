x1 = [1 2 2 1.5 3 3 2.5];
y1 = [3 2 3 4 2 3 2.5];
x2 = [4 4 5 5 4.5 6 5.5 5.5];
y2 = [5 6 4 5 6 4.5 5 6];
x3 = [5, 5.5 6 6 5.5 6.5 6.5 4.8];
y3 = [1 2.5 1 2 1.5 2 1.5 2];

plot(x1, y1, 'bo', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x2, y2, 'rx', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x3, y3, 'gs', 'Markersize', 10, 'linewidth', 2);
hold off;
axis([0 7 0 7]);
xlabel('x_1'); ylabel('x_2');
legend('y = 1', 'y = 0', 'y = 2', 'fontsize', 8, 'location', 'northwest');
title('Multiclass Classification: One-vs-all')

figure(2)
title('Multiclass Classification: One-vs-all')
subplot(1, 3, 1)
plot(x1, y1, 'bo', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x2, y2, 'rx', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x3, y3, 'bo', 'Markersize', 10, 'linewidth', 2);
hold off;
axis([0 7 0 7]);
xlabel('x_1'); ylabel('x_2');
% legend('y = 1', 'y = 0', 'y = 2', 'fontsize', 8, 'location', 'northwest');

subplot(1, 3, 2)
plot(x1, y1, 'bo', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x2, y2, 'bo', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x3, y3, 'rx', 'Markersize', 10, 'linewidth', 2);
hold off;
axis([0 7 0 7]);
xlabel('x_1'); ylabel('x_2');
% legend('y = 1', 'y = 0', 'y = 2', 'fontsize', 8, 'location', 'northwest');

subplot(1, 3, 3)
plot(x1, y1, 'rx', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x2, y2, 'bo', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x3, y3, 'bo', 'Markersize', 10, 'linewidth', 2);
hold off;
axis([0 7 0 7]);
xlabel('x_1'); ylabel('x_2');