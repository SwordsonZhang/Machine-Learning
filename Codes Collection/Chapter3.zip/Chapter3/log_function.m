clear;clc;

x = 0 : 0.000001 : 1;
y = -log(x);
plot(x, y, 'linewidth', 2.5);
set(gca, 'fontsize', 12)
xlabel('x', 'fontsize', 12);
ylabel('y', 'fontsize', 12);
legend('y = -log(x)')
grid on
