clear;clc;
z = -10 : 0.1 : 10;
g = 1 ./ (1 + exp(-z));
plot(z, g, 'b-', 'linewidth', 3)
grid on

hold on
plot(zeros(11, 1), 0:0.1:1, 'r--', 'linewidth', 3)
hold on
plot(-10:1:10, ones(21, 1) * 0.5, 'r--', 'linewidth', 3)
hold off
% axis([-10 10 -0.1 1.1])
set(gca, 'Fontsize', 12)
xlabel('z', 'Fontsize', 12); ylabel('g', 'Fontsize', 12)

