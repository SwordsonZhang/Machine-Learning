x1 = [1 2 2 1.5 3 3 2.5];
y1 = [3 2 3 4 2 3 2.5];
x2 = [4 4 5 5 4.5 6 5.5 5.5];
y2 = [5 6 4 5 6 4.5 5 6];


plot(x1, y1, 'bo', 'Markersize', 10, 'linewidth', 2.5);
hold on;
plot(x2, y2, 'rx', 'Markersize', 10, 'linewidth', 2.5);

legend('y = 1', 'y = 0', 'Fontsize', 8, 'location', 'northeast');
% grid on

l_y1 = 0.5 : 0.1 : 6.5;
l_x1 = ones(length(l_y1), 1) * 3.5;
plot(l_x1, l_y1, 'k', 'linewidth', 2.5)
text(3.6, 6.5, 'hyperplane-1', 'color', 'k')

syms x
y = -0.5 * x + 6;
h1 = ezplot(y, [1, 6.5]);
set(h1, 'color', 'g', 'linewidth', 2.5);
text(5.5, 3.4, 'hyperplane-2', 'color', 'g')

syms x
y = -2 * x + 11;
h1 = ezplot(y, [2.25, 5.25]);
set(h1, 'color', 'm', 'linewidth', 2.5);
text(4.2, 0.4, 'max-margin hyperplane', 'color', 'm')

syms x
y = -2 * x + 13;
h1 = ezplot(y, [3.2, 6]);
set(h1, 'color', 'm', 'linewidth', 2.5, 'linestyle', '--');

syms x
y = -2 * x + 9;
h1 = ezplot(y, [1.5, 4.2]);
set(h1, 'color', 'm', 'linewidth', 2.5, 'linestyle', '--');

syms x
y = 0.5 * x - 1;
h1 = ezplot(y, [4, 5.6]);
set(h1, 'color', 'c', 'linewidth', 2.5, 'linestyle', '--');

text(5.2, 1.6, '\leftarrowmax-margin', 'color', 'c', 'linewidth', 2.5)
hold off
axis([0 7 0 7]);
xlabel('x_1'); ylabel('x_2');
title('SVMs:the mauve line is the maximum-margin hyperplane')
set(gcf,'Position',[500,500,500,500]) 

