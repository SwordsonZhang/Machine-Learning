clear; clc;

l = [3; 5];
x1 = 0 : 0.1 : 6;
x2 = 0 : 0.1 : 10;
x = [];
f = [];

figure(1)
Sigma = 0.5;
for i = 1 : length(x1)
    for j = 1 : length(x2)
        xx = [x1(i),x2(j)];
        x = [xx; x];
        f(j, i) = exp(-(xx' - l)' * (xx' - l) / (2 * Sigma));
    end
end
[X, Y] = meshgrid(x1, x2);
subplot(1, 3, 1)
surf(X, Y, f);
set(gca, 'fontsize', 12)
title('\sigma^2 = 0.5', 'fontsize', 15)

Sigma = 1;
for i = 1 : length(x1)
    for j = 1 : length(x2)
        xx = [x1(i),x2(j)];
        x = [xx; x];
        f(j, i) = exp(-(xx' - l)' * (xx' - l) / (2 * Sigma));
    end
end
[X, Y] = meshgrid(x1, x2);
subplot(1, 3, 2)
surf(X, Y, f);
set(gca, 'fontsize', 12)
title('\sigma^2 = 1', 'fontsize', 15)

Sigma = 3;
for i = 1 : length(x1)
    for j = 1 : length(x2)
        xx = [x1(i),x2(j)];
        x = [xx; x];
        f(j, i) = exp(-(xx' - l)' * (xx' - l) / (2 * Sigma));
    end
end
[X, Y] = meshgrid(x1, x2);
subplot(1, 3, 3)
surf(X, Y, f);
set(gca, 'fontsize', 12)
title('\sigma^2 = 3', 'fontsize', 15)

set(gcf,'Position',[500,500,1500,500]) 