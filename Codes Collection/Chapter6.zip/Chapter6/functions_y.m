clear;clc;

syms z
y1 = -log(1 / (1 + exp(-z)));
y2 = -log(1 - 1 / (1 + exp(-z)));
%%%%%%%%%%%%% figure(1) %%%%%%%%%%%%%
figure(1)
subplot(1, 2, 1)
h1 = ezplot(y1, [-3 3]);
set(h1, 'color', 'r', 'linewidth', 2)
axis([-3 3 0 3.5])

subplot(1, 2, 2)
h2 = ezplot(y2, [-3 3]);
set(h2, 'color', 'r', 'linewidth', 2)
axis([-3 3 0 3.5])
%%%%%%%%%%%% figure(2) %%%%%%%%%%%%%%%%
figure(2)
subplot(1, 2, 1)
h1 = ezplot(y1, [-3 3]);
set(h1, 'color', 'r', 'linewidth', 2)
hold on
y3 = -0.625 * z + 0.625;
h3 = ezplot(y3, [-3 1]);
set(h3, 'color', 'b', 'linewidth', 2)

z_1 = 1 : 0.1 : 3;
y_1 = zeros(length(z_1), 1);
plot(z_1, y_1, 'b', 'linewidth', 2)
hold off
axis([-3 3 0 3.5])
%%%%%%%%%%
subplot(1, 2, 2)
h2 = ezplot(y2, [-3 3]);
set(h2, 'color', 'r', 'linewidth', 2)
hold on
y4 = 0.625 * z + 0.625;
h4 = ezplot(y4, [-1 3]);
set(h4, 'color', 'b', 'linewidth', 2)

z_2 = -3 : 0.1 : -1;
y_2 = zeros(length(z_2), 1);
plot(z_2, y_2, 'b', 'linewidth', 2)
hold off
axis([-3 3 0 3.5])