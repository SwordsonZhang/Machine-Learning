clear; clc;
x1 = [1 2 2 1.5 3 3 2.5];
y1 = [3 2 3 4 2 3 2.5];
x2 = [4 4 5 5 4.5 6 5.5 5.5];
y2 = [5 6 4 5 6 4.5 5 6];

figure(1);
plot(x1, y1, 'bo', 'Markersize', 10, 'linewidth', 2);
hold on;
plot(x2, y2, 'bo', 'Markersize', 10, 'linewidth', 2);
hold off;
axis([0 7 0 7]);
xlabel('x_1'); ylabel('x_2');
title('K-Means Clustering')

xc1 = 1; yc1 = 3;
xc2 = 2; yc2 = 2;

mu = [xc1, yc1; xc2, yc2];
x = [1, 3; 2, 2; 2, 3; 1.5, 4; 3, 2; 3, 3; 2.5, 2.5;...
     4, 5; 4, 6; 5, 4; 5, 5; 4.5, 6; 6, 4.5; 5.5, 5; 5.5, 6];
m = size(x, 1);
k = size(mu, 1);
c = zeros(m, k);
K = zeros(m, 1);
Mu = [xc1, yc1, xc2, yc2];
J = [];
iterations = 5;
e = 1;
epsilon = 0.0001;
while (e > epsilon)
    for i = 1 : m
        for j = 1 : k
            c(i, j) = (x(i, :) - mu(j, :)) * (x(i, :) - mu(j, :))';
        end
        [v, n] = min(c(i, :));
        K(i) = n;
    end
    
    X1 = x(K==1, :);
    X2 = x(K==2, :);    
    n1 = size(X1, 1);
    n2 = size(X2, 1);
    mu(1, :) = sum(X1) / n1;
    mu(2, :) = sum(X2) / n2;
    Mu = [Mu; mu(1, :), mu(2, :)];
    
    J1 = 0;
    for i = 1 : n1
        J1 = J1 + (X1(i, :) - mu(1, :)) * (X1(i, :) - mu(1, :))';
    end
    for i = 1 : n2
        J1 = J1 + (X2(i, :) - mu(2, :)) * (X2(i, :) - mu(2, :))';
    end
    
    J = [J; J1];
    if size(J, 1) == 1
        continue;
    else
        e = J(size(J, 1) - 1) - J1;
    end
end

hold on
for num = 1 : size(Mu, 1)
    plot(Mu(num, 1), Mu(num, 2), '+m', 'linewidth', 2);
    plot(Mu(num, 3), Mu(num, 4), '+r', 'linewidth', 2); 
end
hold off


















